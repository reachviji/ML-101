# ML_Assignment1
Techknow school assignment
This assignment consists of 9 exercises.

My code accepts inputs from the user before performing the action.

# Assignments are:
Assignment 1.1: Python program to find the largest element among three Numbers \
Assignment 1.2: Python Program to check given number is Prime number or not \
Assignment 1.3: Python Program to display all prime numbers within an interval \
Assignment 1.4: Python Program to check given number is Prime number or not (using break) \
Assignment 2.1: Python Program to Check where a String is Palindrome or not? \
Assignment 2.2: Python Program to Sort Words in Alphabetic Order? \
Assignment 3.1: Python program to print Highest Common Factor (HCF) of two numbers \
Assignment 3.2: Python program to make a simple calculator that can add, subtract, multiply and division \
Assignment 3.3: Python program to display the Fibonacci sequence up to nth term without and with recursive function

Lastly,Assignments1.html has all the code with output done in Jupyter Notebook
